﻿namespace PlayersAndMonsters.ElfClass
{
    public class Elf : Hero
    {
        public Elf(string username, int level) : base(username, level)
        {
        }
    }
}
